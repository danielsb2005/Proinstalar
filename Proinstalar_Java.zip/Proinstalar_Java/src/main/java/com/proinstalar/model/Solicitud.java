package com.proinstalar.model;

import com.google.gson.annotations.SerializedName;

/** Solicitud de servicio con los datos del cliente y del tipo de servicio ya unidos (para la respuesta JSON). */
public class Solicitud {
    public int id;
    public String estado;
    public String comentarios;
    @SerializedName("creado_en")
    public String creadoEn;
    @SerializedName("actualizado_en")
    public String actualizadoEn;
    public String cliente;
    public String telefono;
    public String direccion;
    @SerializedName("tipo_servicio")
    public String tipoServicio;
}
