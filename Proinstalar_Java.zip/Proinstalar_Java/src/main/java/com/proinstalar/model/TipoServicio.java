package com.proinstalar.model;

public class TipoServicio {
    public int id;
    public String nombre;

    public TipoServicio() { }
    public TipoServicio(int id, String nombre) { this.id = id; this.nombre = nombre; }
}
