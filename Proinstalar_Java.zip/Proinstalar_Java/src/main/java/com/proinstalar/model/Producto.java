package com.proinstalar.model;

import com.google.gson.annotations.SerializedName;

public class Producto {
    public int id;
    public String nombre;
    public String descripcion;
    public int precio;
    public String imagen;
    public int activo = 1;
    public String categoria;
    @SerializedName("categoria_id")
    public int categoriaId;
}
