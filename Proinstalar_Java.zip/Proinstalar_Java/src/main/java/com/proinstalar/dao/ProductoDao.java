package com.proinstalar.dao;

import com.proinstalar.config.Db;
import com.proinstalar.model.Producto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductoDao {
    private static final String BASE =
        "SELECT p.id, p.nombre, p.descripcion, p.precio, p.imagen, p.activo, c.nombre AS categoria, p.categoria_id "
      + "FROM productos p JOIN categorias c ON c.id = p.categoria_id";

    public List<Producto> buscar(String categoria, String q, boolean incluirInactivos) {
        StringBuilder sql = new StringBuilder(BASE);
        List<Object> params = new ArrayList<>();
        List<String> where = new ArrayList<>();
        if (!incluirInactivos) where.add("p.activo = 1");
        if (categoria != null && !categoria.isEmpty()) { where.add("c.nombre = ?"); params.add(categoria); }
        if (q != null && !q.isEmpty()) {
            where.add("(p.nombre LIKE ? OR p.descripcion LIKE ?)");
            params.add("%" + q + "%");
            params.add("%" + q + "%");
        }
        if (!where.isEmpty()) sql.append(" WHERE ").append(String.join(" AND ", where));
        sql.append(" ORDER BY p.id");

        List<Producto> lista = new ArrayList<>();
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) ps.setObject(i + 1, params.get(i));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }
        } catch (SQLException e) { throw new DaoException(e); }
        return lista;
    }

    public Producto porId(int id) {
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(BASE + " WHERE p.id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? mapear(rs) : null; }
        } catch (SQLException e) { throw new DaoException(e); }
    }

    public Producto crear(Producto p) {
        String sql = "INSERT INTO productos (nombre, descripcion, precio, imagen, categoria_id) VALUES (?,?,?,?,?)";
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.nombre);
            ps.setString(2, p.descripcion);
            ps.setInt(3, p.precio);
            ps.setString(4, p.imagen);
            ps.setInt(5, p.categoriaId);
            ps.executeUpdate();
            try (ResultSet k = ps.getGeneratedKeys()) {
                k.next();
                return porId(k.getInt(1));
            }
        } catch (SQLException e) { throw new DaoException(e); }
    }

    public Producto actualizar(int id, Producto p) {
        String sql = "UPDATE productos SET nombre=?, descripcion=?, precio=?, imagen=?, categoria_id=?, activo=? WHERE id=?";
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.nombre);
            ps.setString(2, p.descripcion);
            ps.setInt(3, p.precio);
            ps.setString(4, p.imagen);
            ps.setInt(5, p.categoriaId);
            ps.setInt(6, p.activo);
            ps.setInt(7, id);
            ps.executeUpdate();
        } catch (SQLException e) { throw new DaoException(e); }
        return porId(id);
    }

    public boolean eliminar(int id) {
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement("DELETE FROM productos WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { throw new DaoException(e); }
    }

    private Producto mapear(ResultSet rs) throws SQLException {
        Producto p = new Producto();
        p.id = rs.getInt("id");
        p.nombre = rs.getString("nombre");
        p.descripcion = rs.getString("descripcion");
        p.precio = rs.getInt("precio");
        p.imagen = rs.getString("imagen");
        p.activo = rs.getInt("activo");
        p.categoria = rs.getString("categoria");
        p.categoriaId = rs.getInt("categoria_id");
        return p;
    }
}
