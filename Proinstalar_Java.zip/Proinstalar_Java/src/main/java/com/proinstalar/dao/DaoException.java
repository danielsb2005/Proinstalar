package com.proinstalar.dao;

public class DaoException extends RuntimeException {
    public DaoException(Throwable causa) { super("Error de acceso a datos: " + causa.getMessage(), causa); }
}
