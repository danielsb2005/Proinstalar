package com.proinstalar.dao;

import com.proinstalar.config.Db;
import com.proinstalar.model.Solicitud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class SolicitudDao {
    private static final String BASE =
        "SELECT s.id, s.estado, s.comentarios, s.creado_en, s.actualizado_en, "
      + "c.nombre AS cliente, c.telefono, c.direccion, t.nombre AS tipo_servicio "
      + "FROM solicitudes_servicio s "
      + "JOIN clientes c ON c.id = s.cliente_id "
      + "JOIN tipos_servicio t ON t.id = s.tipo_servicio_id";

    /** Crea (o reutiliza por teléfono) el cliente y registra la solicitud en UNA transacción. */
    public Solicitud crear(String nombre, String telefono, String direccion, int tipoServicioId, String comentarios) {
        int solicitudId;
        try (Connection c = Db.get()) {
            c.setAutoCommit(false);
            try {
                int clienteId = -1;
                try (PreparedStatement ps = c.prepareStatement("SELECT id FROM clientes WHERE telefono = ?")) {
                    ps.setString(1, telefono);
                    try (ResultSet rs = ps.executeQuery()) { if (rs.next()) clienteId = rs.getInt(1); }
                }
                if (clienteId > 0) {
                    try (PreparedStatement ps = c.prepareStatement("UPDATE clientes SET nombre = ?, direccion = ? WHERE id = ?")) {
                        ps.setString(1, nombre);
                        ps.setString(2, direccion);
                        ps.setInt(3, clienteId);
                        ps.executeUpdate();
                    }
                } else {
                    try (PreparedStatement ps = c.prepareStatement(
                            "INSERT INTO clientes (nombre, telefono, direccion) VALUES (?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
                        ps.setString(1, nombre);
                        ps.setString(2, telefono);
                        ps.setString(3, direccion);
                        ps.executeUpdate();
                        try (ResultSet k = ps.getGeneratedKeys()) { k.next(); clienteId = k.getInt(1); }
                    }
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO solicitudes_servicio (cliente_id, tipo_servicio_id, comentarios) VALUES (?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, clienteId);
                    ps.setInt(2, tipoServicioId);
                    ps.setString(3, comentarios);
                    ps.executeUpdate();
                    try (ResultSet k = ps.getGeneratedKeys()) { k.next(); solicitudId = k.getInt(1); }
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) { throw new DaoException(e); }
        return porId(solicitudId);
    }

    public List<Solicitud> listar(String estado) {
        String sql = BASE + (estado != null ? " WHERE s.estado = ?" : "") + " ORDER BY s.id DESC";
        List<Solicitud> l = new ArrayList<>();
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (estado != null) ps.setString(1, estado);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) l.add(mapear(rs)); }
        } catch (SQLException e) { throw new DaoException(e); }
        return l;
    }

    public Solicitud porId(int id) {
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(BASE + " WHERE s.id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? mapear(rs) : null; }
        } catch (SQLException e) { throw new DaoException(e); }
    }

    public Solicitud cambiarEstado(int id, String estado) {
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(
                "UPDATE solicitudes_servicio SET estado = ?, actualizado_en = CURRENT_TIMESTAMP WHERE id = ?")) {
            ps.setString(1, estado);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) { throw new DaoException(e); }
        return porId(id);
    }

    private Solicitud mapear(ResultSet rs) throws SQLException {
        Solicitud s = new Solicitud();
        s.id = rs.getInt("id");
        s.estado = rs.getString("estado");
        s.comentarios = rs.getString("comentarios");
        s.creadoEn = formato(rs.getTimestamp("creado_en"));
        s.actualizadoEn = formato(rs.getTimestamp("actualizado_en"));
        s.cliente = rs.getString("cliente");
        s.telefono = rs.getString("telefono");
        s.direccion = rs.getString("direccion");
        s.tipoServicio = rs.getString("tipo_servicio");
        return s;
    }

    private String formato(Timestamp t) {
        if (t == null) return null;
        String s = t.toString();
        return s.length() >= 19 ? s.substring(0, 19) : s;
    }
}
