package com.proinstalar.dao;

import com.proinstalar.config.Db;
import com.proinstalar.model.Categoria;
import com.proinstalar.model.TipoServicio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CatalogoDao {

    public List<Categoria> categorias() {
        List<Categoria> l = new ArrayList<>();
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement("SELECT id, nombre FROM categorias ORDER BY id");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) l.add(new Categoria(rs.getInt(1), rs.getString(2)));
        } catch (SQLException e) { throw new DaoException(e); }
        return l;
    }

    public List<TipoServicio> tiposServicio() {
        List<TipoServicio> l = new ArrayList<>();
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement("SELECT id, nombre FROM tipos_servicio ORDER BY id");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) l.add(new TipoServicio(rs.getInt(1), rs.getString(2)));
        } catch (SQLException e) { throw new DaoException(e); }
        return l;
    }

    public boolean existeCategoria(int id) { return existe("SELECT 1 FROM categorias WHERE id = ?", id); }

    public boolean existeTipoServicio(int id) { return existe("SELECT 1 FROM tipos_servicio WHERE id = ?", id); }

    private boolean existe(String sql, int id) {
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        } catch (SQLException e) { throw new DaoException(e); }
    }
}
