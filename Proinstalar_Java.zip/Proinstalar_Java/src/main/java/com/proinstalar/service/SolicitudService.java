package com.proinstalar.service;

import com.google.gson.JsonObject;
import com.proinstalar.dao.CatalogoDao;
import com.proinstalar.dao.SolicitudDao;
import com.proinstalar.model.Solicitud;
import com.proinstalar.util.Json;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SolicitudService {
    public static final List<String> ESTADOS = Arrays.asList("PENDIENTE", "EN_PROCESO", "COMPLETADA", "CANCELADA");

    /** Transiciones de estado permitidas (regla de negocio). */
    private static final Map<String, List<String>> TRANSICIONES = new HashMap<>();
    static {
        TRANSICIONES.put("PENDIENTE", Arrays.asList("EN_PROCESO", "CANCELADA"));
        TRANSICIONES.put("EN_PROCESO", Arrays.asList("COMPLETADA", "CANCELADA"));
        TRANSICIONES.put("COMPLETADA", new ArrayList<>());
        TRANSICIONES.put("CANCELADA", new ArrayList<>());
    }

    private final SolicitudDao dao = new SolicitudDao();
    private final CatalogoDao catalogo = new CatalogoDao();

    public Solicitud crear(JsonObject d) {
        List<String> errores = new ArrayList<>();
        String nombre = Json.texto(d, "nombre");
        nombre = nombre == null ? "" : nombre.trim();
        String telRaw = Json.textoONumero(d, "telefono");
        String telefono = telRaw == null ? "" : telRaw.replaceAll("[\\s-]", "");
        String direccion = Json.texto(d, "direccion");
        direccion = direccion == null ? "" : direccion.trim();
        Integer tipoId = Json.entero(d, "tipo_servicio_id");
        String comentarios = Json.texto(d, "comentarios");

        if (nombre.length() < 3) errores.add("nombre: mínimo 3 caracteres");
        if (nombre.length() > 100) errores.add("nombre: máximo 100 caracteres");
        if (!telefono.matches("^\\+?\\d{7,13}$")) errores.add("telefono: debe tener entre 7 y 13 dígitos");
        if (direccion.length() < 5) errores.add("direccion: mínimo 5 caracteres");
        if (direccion.length() > 200) errores.add("direccion: máximo 200 caracteres");
        if (tipoId == null || !catalogo.existeTipoServicio(tipoId)) errores.add("tipo_servicio_id: no existe");
        if (!Json.esNuloOAusente(d, "comentarios") && comentarios == null) errores.add("comentarios: debe ser texto");
        else if (comentarios != null && comentarios.length() > 500) errores.add("comentarios: máximo 500 caracteres");
        if (!errores.isEmpty()) throw new HttpException(400, "Datos de solicitud inválidos", errores);

        String com = (comentarios == null || comentarios.trim().isEmpty()) ? null : comentarios.trim();
        return dao.crear(nombre, telefono, direccion, tipoId, com);
    }

    public List<Solicitud> listar(String estado) {
        if (estado != null && !estado.isEmpty() && !ESTADOS.contains(estado)) {
            throw new HttpException(400, "estado inválido. Valores: " + String.join(", ", ESTADOS));
        }
        return dao.listar(estado == null || estado.isEmpty() ? null : estado);
    }

    public Solicitud obtener(int id) {
        Solicitud s = dao.porId(id);
        if (s == null) throw new HttpException(404, "Solicitud no encontrada");
        return s;
    }

    public Solicitud cambiarEstado(int id, String estado) {
        Solicitud s = obtener(id);
        if (estado == null || !ESTADOS.contains(estado)) {
            throw new HttpException(400, "estado inválido. Valores: " + String.join(", ", ESTADOS));
        }
        if (!TRANSICIONES.get(s.estado).contains(estado)) {
            throw new HttpException(409, "No se puede pasar de " + s.estado + " a " + estado);
        }
        return dao.cambiarEstado(id, estado);
    }
}
