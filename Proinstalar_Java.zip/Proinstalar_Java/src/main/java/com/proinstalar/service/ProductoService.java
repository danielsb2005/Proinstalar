package com.proinstalar.service;

import com.google.gson.JsonObject;
import com.proinstalar.dao.CatalogoDao;
import com.proinstalar.dao.ProductoDao;
import com.proinstalar.model.Producto;
import com.proinstalar.util.Json;

import java.util.ArrayList;
import java.util.List;

public class ProductoService {
    private final ProductoDao dao = new ProductoDao();
    private final CatalogoDao catalogo = new CatalogoDao();

    public List<Producto> listar(String categoria, String q, boolean admin) {
        return dao.buscar(categoria, q, admin);
    }

    public Producto obtener(int id) {
        Producto p = dao.porId(id);
        if (p == null) throw new HttpException(404, "Producto no encontrado");
        return p;
    }

    public Producto crear(JsonObject datos) {
        return dao.crear(validar(datos));
    }

    public Producto actualizar(int id, JsonObject datos) {
        obtener(id);
        Producto p = validar(datos);
        p.activo = Json.booleanoONulo(datos, "activo", true) ? 1 : 0;
        return dao.actualizar(id, p);
    }

    public void eliminar(int id) {
        if (!dao.eliminar(id)) throw new HttpException(404, "Producto no encontrado");
    }

    /** Reglas de validación de un producto; lanza 400 con la lista de errores. */
    private Producto validar(JsonObject d) {
        List<String> errores = new ArrayList<>();
        String nombre = Json.texto(d, "nombre");
        String descripcion = Json.texto(d, "descripcion");
        Integer precio = Json.entero(d, "precio");
        Integer categoriaId = Json.entero(d, "categoria_id");
        String imagen = Json.texto(d, "imagen");

        if (nombre == null || nombre.trim().length() < 3) errores.add("nombre: mínimo 3 caracteres");
        if (descripcion == null || descripcion.trim().isEmpty()) errores.add("descripcion: obligatoria");
        if (precio == null || precio < 0) errores.add("precio: entero >= 0");
        if (!Json.esNuloOAusente(d, "imagen") && imagen == null) errores.add("imagen: debe ser texto");
        if (categoriaId == null || !catalogo.existeCategoria(categoriaId)) errores.add("categoria_id: no existe");
        if (!errores.isEmpty()) throw new HttpException(400, "Datos de producto inválidos", errores);

        Producto p = new Producto();
        p.nombre = nombre.trim();
        p.descripcion = descripcion.trim();
        p.precio = precio;
        p.imagen = imagen;
        p.categoriaId = categoriaId;
        return p;
    }
}
