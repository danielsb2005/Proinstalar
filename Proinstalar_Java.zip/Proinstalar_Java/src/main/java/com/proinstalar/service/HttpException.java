package com.proinstalar.service;

import java.util.List;

/** Error de negocio que se traduce a un código HTTP (400, 401, 404, 409, 429...). */
public class HttpException extends RuntimeException {
    private final int status;
    private final List<String> detalles;

    public HttpException(int status, String mensaje) { this(status, mensaje, null); }

    public HttpException(int status, String mensaje, List<String> detalles) {
        super(mensaje);
        this.status = status;
        this.detalles = detalles;
    }

    public int getStatus() { return status; }
    public List<String> getDetalles() { return detalles; }
}
