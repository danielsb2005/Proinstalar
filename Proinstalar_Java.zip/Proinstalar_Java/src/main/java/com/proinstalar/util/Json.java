package com.proinstalar.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.math.BigDecimal;

/** Utilidades para leer campos de un JSON de forma segura (sin lanzar excepciones por tipos incorrectos). */
public final class Json {
    public static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();

    private Json() { }

    /** Devuelve el texto si el campo es un string; si no, null. */
    public static String texto(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isString()) ? e.getAsString() : null;
    }

    /** Devuelve texto si es string o número; si no, null. */
    public static String textoONumero(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return (e != null && e.isJsonPrimitive()) ? e.getAsString() : null;
    }

    /** Devuelve el entero si el campo es un número entero; si no, null. */
    public static Integer entero(JsonObject o, String k) {
        JsonElement e = o.get(k);
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isNumber()) return null;
        try { return new BigDecimal(e.getAsString()).intValueExact(); } catch (ArithmeticException | NumberFormatException ex) { return null; }
    }

    public static boolean esNuloOAusente(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return e == null || e.isJsonNull();
    }

    public static boolean booleanoONulo(JsonObject o, String k, boolean porDefecto) {
        JsonElement e = o.get(k);
        if (e == null || !e.isJsonPrimitive() || !e.getAsJsonPrimitive().isBoolean()) return porDefecto;
        return e.getAsBoolean();
    }
}
