package com.proinstalar.web;

import com.google.gson.JsonObject;
import com.proinstalar.model.Solicitud;
import com.proinstalar.service.HttpException;
import com.proinstalar.service.SolicitudService;
import com.proinstalar.util.Json;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/** /api/solicitudes, /api/solicitudes/{id} y /api/solicitudes/{id}/estado */
@WebServlet("/api/solicitudes/*")
public class SolicitudesServlet extends BaseApiServlet {
    private final SolicitudService service = new SolicitudService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (req.getPathInfo() != null && !req.getPathInfo().equals("/")) throw new HttpException(405, "Método no permitido");
        if (!RateLimiter.permitir(req.getRemoteAddr())) {
            throw new HttpException(429, "Demasiadas solicitudes, intenta de nuevo en un minuto");
        }
        Solicitud s = service.crear(cuerpo(req));
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("mensaje", "Solicitud registrada");
        r.put("solicitud", s);
        json(resp, 201, r);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        requiereAdmin(req);
        int id = idDeRuta(req);
        if (id < 0) json(resp, 200, service.listar(req.getParameter("estado")));
        else json(resp, 200, service.obtener(id));
    }

    @Override
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        requiereAdmin(req);
        String[] seg = segmentos(req);
        if (seg.length != 2 || !seg[1].equals("estado")) throw new HttpException(404, "Recurso no encontrado");
        int id = idDeRuta(req);
        JsonObject body = cuerpo(req);
        json(resp, 200, service.cambiarEstado(id, Json.texto(body, "estado")));
    }
}
