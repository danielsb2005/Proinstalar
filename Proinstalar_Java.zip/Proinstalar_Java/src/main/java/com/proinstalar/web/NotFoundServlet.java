package com.proinstalar.web;

import com.proinstalar.service.HttpException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/** Cualquier ruta /api/... que no exista responde 404 en JSON. */
@WebServlet("/api/*")
public class NotFoundServlet extends BaseApiServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
        throw new HttpException(404, "Ruta no encontrada: " + req.getMethod() + " " + req.getRequestURI());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) { doGet(req, resp); }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) { doGet(req, resp); }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) { doGet(req, resp); }

    @Override
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) { doGet(req, resp); }
}
