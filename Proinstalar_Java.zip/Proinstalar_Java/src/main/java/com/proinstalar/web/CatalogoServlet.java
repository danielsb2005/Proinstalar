package com.proinstalar.web;

import com.proinstalar.dao.CatalogoDao;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** /api/categorias y /api/tipos-servicio (listas de apoyo para el frontend) */
@WebServlet({"/api/categorias", "/api/tipos-servicio"})
public class CatalogoServlet extends BaseApiServlet {
    private final CatalogoDao dao = new CatalogoDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (req.getServletPath().equals("/api/categorias")) json(resp, 200, dao.categorias());
        else json(resp, 200, dao.tiposServicio());
    }
}
