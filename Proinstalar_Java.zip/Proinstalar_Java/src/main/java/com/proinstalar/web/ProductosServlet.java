package com.proinstalar.web;

import com.proinstalar.service.HttpException;
import com.proinstalar.service.ProductoService;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/** /api/productos y /api/productos/{id} */
@WebServlet("/api/productos/*")
public class ProductosServlet extends BaseApiServlet {
    private final ProductoService service = new ProductoService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int id = idDeRuta(req);
        if (id < 0) json(resp, 200, service.listar(req.getParameter("categoria"), req.getParameter("q"), esAdmin(req)));
        else json(resp, 200, service.obtener(id));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        requiereAdmin(req);
        if (idDeRuta(req) >= 0) throw new HttpException(405, "Método no permitido");
        json(resp, 201, service.crear(cuerpo(req)));
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        requiereAdmin(req);
        int id = idDeRuta(req);
        if (id < 0) throw new HttpException(405, "Método no permitido");
        json(resp, 200, service.actualizar(id, cuerpo(req)));
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) {
        requiereAdmin(req);
        int id = idDeRuta(req);
        if (id < 0) throw new HttpException(405, "Método no permitido");
        service.eliminar(id);
        sinContenido(resp);
    }
}
