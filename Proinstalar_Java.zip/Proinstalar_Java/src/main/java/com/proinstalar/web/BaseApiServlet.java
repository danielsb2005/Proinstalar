package com.proinstalar.web;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.proinstalar.config.AppConfig;
import com.proinstalar.service.HttpException;
import com.proinstalar.util.Json;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase base de los servlets de la API: respuestas JSON, lectura del cuerpo,
 * autenticación por x-admin-key y manejo central de errores (equivale al errorHandler).
 */
public abstract class BaseApiServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(BaseApiServlet.class.getName());

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        try {
            if ("PATCH".equals(req.getMethod())) doPatch(req, resp);
            else super.service(req, resp);
        } catch (HttpException e) {
            error(resp, e.getStatus(), e.getMessage(), e);
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Error interno", e);
            error(resp, 500, "Error interno del servidor", null);
        }
    }

    /** HttpServlet no trae doPatch: por defecto responde 405. */
    protected void doPatch(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        throw new HttpException(405, "Método no permitido");
    }

    // ---------- Utilidades ----------
    protected void json(HttpServletResponse resp, int status, Object cuerpo) throws IOException {
        resp.setStatus(status);
        resp.getWriter().write(Json.GSON.toJson(cuerpo));
    }

    protected void sinContenido(HttpServletResponse resp) {
        resp.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }

    private void error(HttpServletResponse resp, int status, String mensaje, HttpException e) throws IOException {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("error", mensaje);
        if (e != null && e.getDetalles() != null) m.put("detalles", e.getDetalles());
        resp.setStatus(status);
        resp.getWriter().write(Json.GSON.toJson(m));
    }

    protected JsonObject cuerpo(HttpServletRequest req) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = req.getReader()) {
            char[] buf = new char[2048];
            int n;
            while ((n = r.read(buf)) != -1) {
                sb.append(buf, 0, n);
                if (sb.length() > 50_000) throw new HttpException(413, "Cuerpo demasiado grande");
            }
        }
        try {
            if (JsonParser.parseString(sb.toString()).isJsonObject()) return JsonParser.parseString(sb.toString()).getAsJsonObject();
        } catch (JsonParseException ignored) { /* se informa abajo */ }
        throw new HttpException(400, "JSON malformado");
    }

    protected boolean esAdmin(HttpServletRequest req) {
        String clave = req.getHeader("x-admin-key");
        return clave != null && clave.equals(AppConfig.adminKey());
    }

    protected void requiereAdmin(HttpServletRequest req) {
        if (!esAdmin(req)) throw new HttpException(401, "No autorizado: falta o es incorrecta la cabecera x-admin-key");
    }

    /** Primer segmento de la ruta tras el servlet (ej. /5/estado -> 5). Devuelve -1 si no hay. */
    protected int idDeRuta(HttpServletRequest req) {
        String[] partes = segmentos(req);
        if (partes.length == 0) return -1;
        try { return Integer.parseInt(partes[0]); } catch (NumberFormatException e) { throw new HttpException(404, "Recurso no encontrado"); }
    }

    protected String[] segmentos(HttpServletRequest req) {
        String p = req.getPathInfo();
        if (p == null || p.equals("/")) return new String[0];
        return p.substring(1).split("/");
    }
}
