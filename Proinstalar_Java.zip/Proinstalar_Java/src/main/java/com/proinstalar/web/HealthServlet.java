package com.proinstalar.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@WebServlet("/api/health")
public class HealthServlet extends BaseApiServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("estado", "ok");
        m.put("hora", Instant.now().toString());
        json(resp, 200, m);
    }
}
