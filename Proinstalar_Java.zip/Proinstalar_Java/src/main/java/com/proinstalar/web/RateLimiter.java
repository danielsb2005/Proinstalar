package com.proinstalar.web;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Limita a 10 solicitudes por minuto por IP en el formulario público (anti-spam). */
final class RateLimiter {
    private static final int MAX = 10;
    private static final long VENTANA_MS = 60_000;
    private static final Map<String, Deque<Long>> REGISTRO = new ConcurrentHashMap<>();

    private RateLimiter() { }

    static boolean permitir(String ip) {
        long ahora = System.currentTimeMillis();
        Deque<Long> q = REGISTRO.computeIfAbsent(ip, k -> new ArrayDeque<>());
        synchronized (q) {
            while (!q.isEmpty() && ahora - q.peekFirst() > VENTANA_MS) q.pollFirst();
            if (q.size() >= MAX) return false;
            q.addLast(ahora);
            return true;
        }
    }
}
