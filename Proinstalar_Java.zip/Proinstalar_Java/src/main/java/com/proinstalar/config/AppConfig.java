package com.proinstalar.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/** Lee db.properties. Se puede sobrescribir con -Ddb.url=..., -Ddb.user=..., etc. */
public final class AppConfig {
    private static final Properties PROPS = new Properties();

    static {
        try (InputStream in = AppConfig.class.getResourceAsStream("/db.properties")) {
            if (in != null) PROPS.load(in);
        } catch (IOException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private AppConfig() { }

    public static String get(String key) {
        return System.getProperty(key, PROPS.getProperty(key, ""));
    }

    public static String adminKey() { return get("admin.key"); }
}
