package com.proinstalar.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Entrega conexiones JDBC a MySQL. Cada DAO abre y cierra la suya (try-with-resources). */
public final class Db {
    static {
        String driver = AppConfig.get("db.driver");
        if (!driver.isEmpty()) {
            try { Class.forName(driver); } catch (ClassNotFoundException e) { throw new ExceptionInInitializerError(e); }
        }
    }

    private Db() { }

    public static Connection get() throws SQLException {
        return DriverManager.getConnection(AppConfig.get("db.url"), AppConfig.get("db.user"), AppConfig.get("db.password"));
    }
}
