package com.proinstalar.config;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Al iniciar Tomcat crea la base de datos/tablas si no existen y carga los datos iniciales. */
@WebListener
public class DbInitializer implements ServletContextListener {
    private static final Logger LOG = Logger.getLogger(DbInitializer.class.getName());

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try (Connection c = Db.get(); Statement st = c.createStatement()) {
            ejecutar(c, "/sql/schema.sql");
            try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM productos")) {
                rs.next();
                if (rs.getInt(1) == 0) {
                    ejecutar(c, "/sql/datos.sql");
                    LOG.info("Proinstalar: datos iniciales cargados.");
                }
            }
            LOG.info("Proinstalar: base de datos lista.");
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "No se pudo conectar/inicializar MySQL. Verifica que XAMPP (MySQL) esté iniciado "
                    + "y los datos de db.properties.", e);
        }
    }

    /** Ejecuta un script SQL sencillo: sentencias terminadas en ';' y comentarios con '--'. */
    private void ejecutar(Connection c, String recurso) throws Exception {
        try (InputStream in = DbInitializer.class.getResourceAsStream(recurso);
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
             Statement st = c.createStatement()) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                String t = line.trim();
                if (t.isEmpty() || t.startsWith("--")) continue;
                sb.append(line).append('\n');
                if (t.endsWith(";")) {
                    st.execute(sb.toString().replaceAll(";\\s*$", ""));
                    sb.setLength(0);
                }
            }
        } catch (SQLException e) {
            throw new Exception("Error ejecutando " + recurso + ": " + e.getMessage(), e);
        }
    }
}
