// ============================================
// CONFIGURACIÓN Y ESTADO
// ============================================
// Si el frontend se abre desde el servidor Node, la API está en el mismo origen.
// Si se abre desde GitHub Pages / archivo local, apunta a localhost:3000.
// La API vive en la misma aplicación web de Tomcat (ruta relativa: .../Proinstalar/api).
// Si el frontend se abre desde GitHub Pages o como archivo, se apunta al Tomcat local.
const API = location.protocol.startsWith('http') && !location.hostname.endsWith('github.io')
  ? 'api' : 'http://localhost:8080/Proinstalar/api';

let productos = [];
let tiposServicio = [];
let carrito = [];
let filtroActual = 'Todos';

async function api(ruta, opciones) {
  const r = await fetch(API + ruta, opciones);
  const datos = r.status === 204 ? null : await r.json();
  if (!r.ok) {
    const err = new Error(datos?.error || 'Error de servidor');
    err.detalles = datos?.detalles;
    throw err;
  }
  return datos;
}

const escapar = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

async function cargarDatos() {
  try {
    [productos, tiposServicio] = await Promise.all([api('/productos'), api('/tipos-servicio')]);
    const sel = document.getElementById('gas-tipo');
    sel.innerHTML = '<option value="">Seleccionar...</option>' +
      tiposServicio.map(t => `<option value="${t.id}">${escapar(t.nombre)}</option>`).join('');
    renderProductos();
  } catch (e) {
    document.getElementById('productos-grid').innerHTML =
      '<p style="padding:30px;text-align:center">No se pudo conectar con el servidor. Verifica que Tomcat y MySQL (XAMPP) estén iniciados.</p>';
  }
}

// ============================================
// CATÁLOGO - RENDER Y FILTROS
// ============================================
function renderProductos() {
  const buscar = document.getElementById('buscar-input').value.toLowerCase();
  const grid = document.getElementById('productos-grid');

  const filtrados = productos.filter(p => {
    const matchCat    = filtroActual === 'Todos' || p.categoria === filtroActual;
    const matchBuscar = p.nombre.toLowerCase().includes(buscar) || p.descripcion.toLowerCase().includes(buscar);
    return matchCat && matchBuscar;
  });

  if (!filtrados.length) { grid.innerHTML = '<p style="padding:30px;text-align:center">No se encontraron productos.</p>'; return; }

  grid.innerHTML = filtrados.map(p => `
    <div class="prod-card">
      <div class="prod-img">
        <img src="${escapar(p.imagen || '')}" alt="${escapar(p.nombre)}" class="img-producto">
      </div>
      <div class="prod-info">
        <h3>${escapar(p.nombre)}</h3>
        <p>${escapar(p.descripcion)}</p>
        <div class="prod-precio">$${p.precio.toLocaleString('es-CO')}</div>
        <button class="btn-agregar" onclick="agregarAlCarrito(${p.id})">+ Agregar al carrito</button>
      </div>
    </div>
  `).join('');
}

function setFiltro(cat, btn) {
  filtroActual = cat;
  document.querySelectorAll('.filtro').forEach(b => b.classList.remove('activo'));
  btn.classList.add('activo');
  renderProductos();
}

function filtrarProductos() {
  renderProductos();
}

function filtrarYIr(cat) {
  filtroActual = cat;
  showPage('catalogo');
  document.querySelectorAll('.filtro').forEach(b => {
    b.classList.toggle('activo', b.textContent.trim() === cat);
  });
}

// ============================================
// CARRITO
// ============================================
function agregarAlCarrito(id) {
  const prod = productos.find(p => p.id === id);
  const existente = carrito.find(i => i.id === id);

  if (existente) {
    existente.qty++;
  } else {
    carrito.push({ ...prod, qty: 1 });
  }

  actualizarCarrito();
  mostrarToast(`✅ ${prod.nombre} agregado al carrito`, 'success');
}

function eliminarDelCarrito(id) {
  carrito = carrito.filter(i => i.id !== id);
  actualizarCarrito();
}

function actualizarCarrito() {
  const total = carrito.reduce((s, i) => s + i.precio * i.qty, 0);
  const count = carrito.reduce((s, i) => s + i.qty, 0);

  document.getElementById('carrito-count').textContent = count;

  const itemsEl   = document.getElementById('carrito-items');
  const resumenEl = document.getElementById('carrito-resumen');

  if (carrito.length === 0) {
    itemsEl.innerHTML   = '<div class="carrito-vacio">Tu carrito está vacío 🛒</div>';
    resumenEl.innerHTML = '';
    return;
  }

  itemsEl.innerHTML = carrito.map(i => `
    <div class="carrito-item">
      <div class="carrito-item-icon"><img src="${escapar(i.imagen || '')}" alt="" style="width:40px;height:40px;object-fit:contain"></div>
      <div class="carrito-item-info">
        <h4>${escapar(i.nombre)}</h4>
        <span>x${i.qty} — $${(i.precio * i.qty).toLocaleString('es-CO')}</span>
      </div>
      <button class="btn-eliminar" onclick="eliminarDelCarrito(${i.id})">✕</button>
    </div>
  `).join('');

  const envio      = total >= 200000 ? 0 : 20000;
  const totalFinal = total + envio;

  const envioHtml = envio === 0
    ? '<div class="envio-gratis-badge">🎉 ¡Envío GRATIS por compras mayores a $200.000!</div>'
    : `<div class="resumen-fila envio"><span>Envío</span><span>$${envio.toLocaleString('es-CO')}</span></div>
       <div style="font-size:0.78rem;color:#999;margin-bottom:6px;">Envío gratis en pedidos mayores a $200.000</div>`;

  resumenEl.innerHTML = `
    <div class="carrito-resumen">
      <div class="resumen-fila"><span>Subtotal</span><span>$${total.toLocaleString('es-CO')}</span></div>
      ${envioHtml}
      <div class="resumen-fila total"><span>Total</span><span>$${totalFinal.toLocaleString('es-CO')}</span></div>
      <button class="btn-pedir" onclick="pedirPorWhatsApp()">📲 Pedir por WhatsApp</button>
    </div>
  `;
}

function pedirPorWhatsApp() {
  const items = carrito.map(i => `• ${i.nombre} x${i.qty}: $${(i.precio * i.qty).toLocaleString('es-CO')}`).join('\n');
  const total = carrito.reduce((s, i) => s + i.precio * i.qty, 0);
  const envio = total >= 200000 ? 0 : 20000;

  const msg = encodeURIComponent(
    `Hola Proinstalar, quiero hacer un pedido:\n\n${items}\n\nSubtotal: $${total.toLocaleString('es-CO')}\nEnvío: $${envio.toLocaleString('es-CO')}\nTotal: $${(total + envio).toLocaleString('es-CO')}`
  );
  window.open(`https://wa.me/573223501454?text=${msg}`, '_blank');
}

function toggleCarrito() {
  document.getElementById('carrito-overlay').classList.toggle('open');
}

function cerrarCarritoFuera(e) {
  if (e.target === document.getElementById('carrito-overlay')) {
    toggleCarrito();
  }
}

// ============================================
// NAVEGACIÓN
// ============================================
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + id).classList.add('active');

  document.querySelectorAll('nav a').forEach(a => a.classList.remove('active'));
  const navEl = document.getElementById('nav-' + id);
  if (navEl) navEl.classList.add('active');

  window.scrollTo(0, 0);

  if (id === 'catalogo') renderProductos();
}

function scrollToForm() {
  showPage('servicios');
  setTimeout(() => {
    document.getElementById('form-servicio').scrollIntoView({ behavior: 'smooth' });
  }, 100);
}

// ============================================
// FORMULARIO SERVICIO DE GAS
// ============================================
async function enviarSolicitudGas() {
  const nombre = document.getElementById('gas-nombre').value.trim();
  const tel    = document.getElementById('gas-tel').value.trim();
  const dir    = document.getElementById('gas-dir').value.trim();
  const tipo   = document.getElementById('gas-tipo').value;

  if (!nombre || !tel || !dir || !tipo) {
    mostrarToast('⚠️ Por favor completa todos los campos obligatorios', 'error');
    return;
  }

  try {
    await api('/solicitudes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        nombre, telefono: tel, direccion: dir,
        tipo_servicio_id: Number(tipo),
        comentarios: document.getElementById('gas-comentarios').value.trim() || null,
      }),
    });
    document.getElementById('modal-exito').classList.add('open');
    limpiarFormulario();
  } catch (e) {
    const det = e.detalles ? ' ' + e.detalles.join('; ') : '';
    mostrarToast('⚠️ ' + e.message + det, 'error');
  }
}

function limpiarFormulario() {
  ['gas-nombre', 'gas-tel', 'gas-dir', 'gas-comentarios'].forEach(id => { document.getElementById(id).value = ''; });
  document.getElementById('gas-tipo').value = '';
}

// ============================================
// TOAST
// ============================================
function mostrarToast(msg, tipo) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast ' + tipo + ' show';
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ============================================
// INIT
// ============================================
cargarDatos();
actualizarCarrito();

function cerrarModal() {
  document.getElementById('modal-exito').classList.remove('open');
}
