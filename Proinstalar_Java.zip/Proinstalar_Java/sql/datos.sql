-- Datos iniciales (se cargan solo si la tabla productos está vacía).
INSERT INTO categorias (nombre) VALUES ('Herramientas'), ('Pinturas'), ('Gas');

INSERT INTO tipos_servicio (nombre) VALUES ('Instalación de Gas'), ('Mantenimiento'), ('Venta de Cilindros'), ('Otro');

INSERT INTO productos (nombre, descripcion, precio, imagen, categoria_id) VALUES
 ('Taladro Inalámbrico', '20V con set de brocas incluido', 180000, 'imagenes/herramienta.png', 1),
 ('Juego de Destornilladores', 'Set de 12 piezas con mango ergonómico', 45000, 'imagenes/herramienta1.png', 1),
 ('Nivel Digital', 'Medición precisa con pantalla LED', 62000, 'imagenes/herramienta2.png', 1),
 ('Pintura Vinílica Blanca', 'Cubeta de 4 litros, acabado mate', 95000, 'imagenes/pintura.png', 2),
 ('Pintura Esmalte Rojo', '1 galón, secado rápido', 38000, 'imagenes/pintura1.png', 2),
 ('Rodillo y Bandeja', 'Kit completo para pintura', 25000, 'imagenes/pintura2.png', 2),
 ('Cilindro Gas 10kg', 'Cilindro vacío con válvula de seguridad', 120000, 'imagenes/gas.png', 3),
 ('Manguera para Gas', '2 metros, certificada y flexible', 28000, 'imagenes/gas1.png', 3),
 ('Regulador de Gas', 'Universal con manómetro integrado', 55000, 'imagenes/gas.png', 3);
