# Proinstalar – Back End en Java (Tomcat + MySQL/XAMPP)

Catálogo de productos y solicitudes de servicios de gas.
API REST con **Servlets (Jakarta)**, **Apache Tomcat 10+** y **MySQL** (XAMPP), integrada con el frontend existente.

## Cómo ejecutarlo en NetBeans
1. Abre **XAMPP** e inicia **MySQL** (no hace falta crear la base de datos: la app la crea sola).
2. En NetBeans: **Archivo → Abrir proyecto** y elige esta carpeta (`Proinstalar`). Se reconoce como proyecto Maven.
   La primera vez NetBeans descarga las librerías (necesita internet).
3. Revisa `src/main/resources/db.properties` (por defecto usuario `root`, sin clave, puerto 3306).
4. Clic derecho en el proyecto → **Run**. Si te pide servidor, elige **Apache Tomcat 10 o superior**.
5. Abre en el navegador:
   - (Si NetBeans agrega la versión a la ruta, p. ej. /Proinstalar-1.0/, la dirección exacta sale en la pestaña Output.)
   - Sitio: http://localhost:8080/Proinstalar/
   - Panel admin: http://localhost:8080/Proinstalar/admin.html (clave por defecto `proinstalar-admin-2026`)
   - Pruebas de la API: http://localhost:8080/Proinstalar/pruebas.html

> Tomcat 10+ usa `jakarta.servlet`. Si tu Tomcat fuera 9 o inferior, este proyecto no corre (usa `javax.servlet`).
> Si tu XAMPP trae MySQL en otro puerto o con clave, cámbialo en `db.properties`.

## Generar el .war (opcional)
Clic derecho → **Clean and Build**; el archivo queda en `target/Proinstalar.war` y se puede copiar a `webapps` de Tomcat.

## Endpoints
| Método | Ruta | Acceso |
|---|---|---|
| GET | /api/productos?categoria=&q= | Público |
| POST/PUT/DELETE | /api/productos[/{id}] | Admin |
| POST | /api/solicitudes | Público |
| GET | /api/solicitudes?estado= | Admin |
| PATCH | /api/solicitudes/{id}/estado | Admin |

Admin = cabecera `x-admin-key`. Detalle completo en `docs/Documento_Proinstalar.docx` (sección 5.5).

## Estructura
`src/main/java/com/proinstalar` (config, model, dao, service, web, util) · `src/main/resources` (db.properties, sql) · `src/main/webapp` (frontend).
`sql/` en la raíz trae los scripts por si prefieres importarlos en phpMyAdmin.
